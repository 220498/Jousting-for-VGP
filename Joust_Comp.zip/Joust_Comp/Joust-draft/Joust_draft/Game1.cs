using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace Joust_draft
{
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        Texture2D backgroundTexture;
        Rectangle backgroundRect;


        SpriteFont font;
        Vector2 winnerPos;

        Boolean end;

        Rectangle p1Rect;
        double p1YSpeed;
        double p1XSpeed;
        Boolean p1Jump;
        double p1y;
        double p1x;

        Texture2D pTextRight;
        Texture2D pTextLeft;
        Texture2D pText;

        Texture2D p2TextRight;
        Texture2D p2TextLeft;
        Texture2D p2Text;

        Rectangle p2Rect;
        double p2YSpeed;
        double p2XSpeed;
        Boolean p2Jump;
        double p2y;
        double p2x;

        Rectangle bottom;
        Rectangle top;
        Rectangle left;
        Rectangle right;

        Rectangle plat1Rect;
        Rectangle plat2Rect;
        Rectangle plat3Rect;
        Rectangle plat4Rect;
        Rectangle plat5Rect;
        Rectangle plat6Rect;
        Texture2D platText;
        List<Rectangle> plats = new List<Rectangle>();

        int screenWidth;
        int screenHeight;

        String Winner;

        Boolean Rand;
        Boolean Rand2;

        int gameState;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here
            screenWidth = graphics.GraphicsDevice.Viewport.Width;
            screenHeight = graphics.GraphicsDevice.Viewport.Height;


            backgroundRect = new Rectangle(0, 0, screenWidth, screenHeight);


            Winner = "";
            winnerPos = new Vector2(50, 50);
            //screenHeight/6*5 (bottomY)
            bottom = new Rectangle(0, screenHeight - 20, screenWidth, 20);
            top = new Rectangle(0, -20, screenWidth, 20);
            left = new Rectangle(-20, 0, 20, screenHeight);
            right = new Rectangle(screenWidth, 0, 20, screenHeight);

            plat1Rect = new Rectangle(230, 200, 100, 20);
            plat2Rect = new Rectangle(screenWidth - 120, 107, 120, 20);
            plat3Rect = new Rectangle(0, 107, 120, 20);
            plat4Rect = new Rectangle(0, 300, 120, 20);
            plat5Rect = new Rectangle(screenWidth - 120, 300, 120, 20);
            plat6Rect = new Rectangle(screenWidth - 240, 320, 120, 20);

            gameState = 0;

            plats.Add(plat1Rect);
            plats.Add(plat2Rect);
            plats.Add(plat3Rect);
            plats.Add(plat4Rect);
            plats.Add(plat5Rect);
            plats.Add(plat6Rect);

            p1y = 0;
            p2y = screenHeight - 50;
            p1x = 100;
            p2x = screenWidth - 120;

            Rand = true;
            Rand2 = true;

            end = false;

            p1Rect = new Rectangle(100, 50, 50, 50);
            p2Rect = new Rectangle(screenWidth - 120, 50, 50, 50);
            p1YSpeed = 0;
            p2YSpeed = 0;
            p1XSpeed = 0;
            p2XSpeed = 0;
            p1Jump = false;
            p2Jump = false;

            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            backgroundTexture = Content.Load<Texture2D>("Background");

            pTextRight = Content.Load<Texture2D>("Player1");
            pTextLeft = Content.Load<Texture2D>("Player1FLIPPED");
            pText = pTextRight;

            p2TextRight = Content.Load<Texture2D>("Player2");
            p2TextLeft = Content.Load<Texture2D>("Player2FLIPPED");
            p2Text = p2TextLeft;

            platText = Content.Load<Texture2D>("White Square");

            font = Content.Load<SpriteFont>("SpriteFont1");


            // TODO: use this.Content to load your game content here
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            // Allows the game to exit
            KeyboardState kb = Keyboard.GetState();

            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed)
                this.Exit();
            switch(gameState)
            {
                case (0):
                {
                        if (kb.IsKeyDown(Keys.A))
                        {
                            if (!(p1XSpeed < -4))
                                p1XSpeed -= .05;

                            pText = pTextLeft;

                        }
                        else if (kb.IsKeyDown(Keys.D))
                        {
                            if (!(p1XSpeed > 4))
                                p1XSpeed += .05;

                            pText = pTextRight;
                        }

                        if (p1Rect.Intersects(bottom) || ((p1Rect.Intersects(plat1Rect) || p1Rect.Intersects(plat2Rect) || p1Rect.Intersects(plat3Rect) || p1Rect.Intersects(plat4Rect) || p1Rect.Intersects(plat5Rect) || p1Rect.Intersects(plat6Rect)) && Rand)) //add or other platforms
                        {
                            p1YSpeed = 0;
                        }
                        else
                        {
                            p1YSpeed += .02;
                        }

                        if (kb.IsKeyDown(Keys.W))
                        {
                            p1YSpeed -= .04;
                        }
                        if (p1YSpeed > 4)
                            p1YSpeed = 4;

                        if (p1XSpeed < 0 && !(kb.IsKeyDown(Keys.D) && kb.IsKeyDown(Keys.A)))
                        {
                            p1XSpeed += .01;
                        }
                        else if (p1XSpeed > 0)
                        {
                            p1XSpeed -= .01;
                        }

                        Rand = true;

                        p1y += p1YSpeed;
                        p1x += p1XSpeed;
                        p1Rect.Y = (int)p1y;
                        p1Rect.X = (int)p1x;
                        // add p2XSpeed


                        //Border interaction
                        if (p1Rect.Intersects(bottom)) //add or other platforms
                        {
                            p1y = bottom.Top - p1Rect.Height + 1; //or patform top
                        }
                        if (p1Rect.Intersects(top))
                        {
                            p1y = 0;
                            p1YSpeed = -p1YSpeed / 2;
                        }
                        if (p1Rect.Intersects(left))
                        {
                            p1x = screenWidth - p1Rect.Width - 2;
                            p1Rect.X = screenWidth - p1Rect.Width - 2;
                        }
                        if (p1Rect.Intersects(right))
                        {
                            p1x = 0 + 2;
                            p1Rect.X = 0 + 2;
                        }


                        //
                        ///
                        ///
                        ///
                        //
                        //Platorm intersection stuff
                        for (int x = 0; x < 6; x++)
                        {
                            Rectangle currentplat = plats[x];

                            if (p1Rect.Intersects(currentplat) && p1Rect.Y >= currentplat.Y + currentplat.Height - 5) // intersect with bottom
                            {
                                p1YSpeed = -p1YSpeed / 2;
                                p1y = currentplat.Bottom + 1;
                                Rand = false;
                            }

                            if (p1Rect.Intersects(currentplat) && (p1Rect.Bottom < currentplat.Y)) // intersect with top
                            {
                                p1y = currentplat.Top - p1Rect.Height + 1; //or patform top
                                Rand = true;
                            }

                            if (p1Rect.Intersects(currentplat) && p1Rect.Left < currentplat.Right && p1Rect.Left > currentplat.Right - 5 && p1Rect.Bottom > currentplat.Y + 2) /////////////////////////////////// fix top and bottom collisions witht this
                            {
                                p1XSpeed = -p1XSpeed;
                            }
                            if (p1Rect.Intersects(currentplat) && p1Rect.Right > currentplat.Left && p1Rect.Right < currentplat.Left + 5 && p1Rect.Bottom > currentplat.Y + 2)
                            {
                                p1XSpeed = -p1XSpeed;
                            }
                        }

                        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// P2 physics
                        if (kb.IsKeyDown(Keys.Left))
                        {
                            if (!(p2XSpeed < -4))
                            {
                                p2XSpeed -= .05;
                            }

                            p2Text = p2TextLeft;

                        }
                        if (kb.IsKeyDown(Keys.Right))
                        {
                            if (!(p2XSpeed > 4))
                            {
                                p2XSpeed += .05;
                            }

                            p2Text = p2TextRight;

                        }

                        if (p2Rect.Intersects(bottom) || ((p2Rect.Intersects(plat1Rect) || p2Rect.Intersects(plat2Rect) || p2Rect.Intersects(plat3Rect) || p2Rect.Intersects(plat4Rect) || p2Rect.Intersects(plat5Rect) || p2Rect.Intersects(plat6Rect)) && Rand2)) //add or other platforms
                        {
                            p2YSpeed = 0;
                        }
                        else
                        {
                            p2YSpeed += .02;
                        }

                        if (kb.IsKeyDown(Keys.Up))
                        {
                            p2YSpeed -= .04;
                        }
                        if (p2YSpeed > 4)
                            p2YSpeed = 4;

                        if (p2XSpeed < 0 && !(kb.IsKeyDown(Keys.Right) && kb.IsKeyDown(Keys.Left)))
                        {
                            p2XSpeed += .01;
                        }
                        else if (p2XSpeed > 0)
                        {
                            p2XSpeed -= .01;
                        }

                        Rand2 = true;

                        p2y += p2YSpeed;
                        p2x += p2XSpeed;
                        p2Rect.Y = (int)p2y;
                        p2Rect.X = (int)p2x;
                        // add p2XSpeed

                        //player 2 screen interaction
                        if (p2Rect.Intersects(bottom)) //add or other platforms
                        {
                            p2y = bottom.Top - p2Rect.Height + 1; //or patform top
                        }
                        if (p2Rect.Intersects(top))
                        {
                            p2YSpeed *= -1;
                        }
                        if (p2Rect.Intersects(left))
                        {
                            p2x = screenWidth - p2Rect.Width - 2;
                            p2Rect.X = screenWidth - p2Rect.Width - 2;
                        }
                        if (p2Rect.Intersects(right))
                        {
                            p2x = 0 + 2;
                            p2Rect.X = 0 + 2;
                        }

                        for (int x = 0; x < 6; x++)
                        {
                            Rectangle currentplat = plats[x];

                            if (p2Rect.Intersects(currentplat) && p2Rect.Y >= currentplat.Y + currentplat.Height - 5) // intersect with bottom
                            {
                                p2YSpeed = -p2YSpeed / 2;
                                p2y = currentplat.Bottom + 1;
                                Rand = false;
                            }

                            if (p2Rect.Intersects(currentplat) && (p2Rect.Bottom < currentplat.Y)) // intersect with top
                            {
                                p2y = currentplat.Top - p2Rect.Height + 1; //or patform top
                                Rand = true;
                            }

                            if (p2Rect.Intersects(currentplat) && p2Rect.Left < currentplat.Right && p2Rect.Left > currentplat.Right - 5 && p2Rect.Bottom > currentplat.Y + 2) /////////////////////////////////// fix top and bottom collisions witht this
                            {
                                p2XSpeed = -p2XSpeed;
                            }
                            if (p2Rect.Intersects(currentplat) && p2Rect.Right > currentplat.Left && p1Rect.Right < currentplat.Left + 5 && p2Rect.Bottom > currentplat.Y + 2)
                            {
                                p2XSpeed = -p2XSpeed;
                            }
                        }

                        ////////////////////////////////////////////////////////////Kill

                        if (p1Rect.Intersects(p2Rect) && !end)
                        {
                            if (p1Rect.Y > p2Rect.Y)
                            {
                                Winner = "Player2";
                            }
                            if (p1Rect.Y < p2Rect.Y)
                            {
                                Winner = "Player1";
                            }
                            end = true;
                        }
                        if(end && kb.IsKeyDown(Keys.R))
                        {
                            gameState = 1;
                        }
                        break;
                }
                case (1):
                {
                    Winner = "";
                        p1y = 0;
                        p2y = screenHeight - 50;
                        p1x = 100;
                        p2x = screenWidth - 120;

                        Rand = true;
                        Rand2 = true;

                        end = false;

                        p1Rect = new Rectangle(100, 50, 50, 50);
                        p2Rect = new Rectangle(screenWidth - 120, 50, 50, 50);
                        p1YSpeed = 0;
                        p2YSpeed = 0;
                        p1XSpeed = 0;
                        p2XSpeed = 0;
                        p1Jump = false;
                        p2Jump = false;

                        pText = pTextRight;
                        p2Text = p2TextLeft;

                        gameState = 0;
                    break;
                }
            }

            // TODO: Add your update logic here
            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            // TODO: Add your drawing code here
            spriteBatch.Begin();
            //spriteBatch.Draw(backgroundTexture, backgroundRect, Color.White);

            spriteBatch.Draw(pTextRight, p1Rect, Color.White);
            spriteBatch.Draw(p2TextRight, p2Rect, Color.White);

            spriteBatch.Draw(platText, bottom, Color.White);
            for (int x = 0; x < 6; x++)
            {
                Rectangle currentplat = plats[x];
                spriteBatch.Draw(platText, currentplat, Color.White);
            }
            //    spriteBatch.Draw(platText, plat1Rect, Color.White); // if you want to make translucent just change Color.White to Color.Transparent
            //spriteBatch.Draw(platText, plat2Rect, Color.White);
            //spriteBatch.Draw(platText, plat3Rect, Color.White);

            spriteBatch.DrawString(font, Winner, winnerPos, Color.White);
            spriteBatch.End();

            base.Draw(gameTime);
        }
    }
    

}
